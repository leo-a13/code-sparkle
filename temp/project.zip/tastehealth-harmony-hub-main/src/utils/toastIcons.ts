// Use simple emoji strings instead of React elements for toast icons
export const TOAST_ICONS = {
  success: '✅',
  error: '❌',
  warning: '⚠️',
  info: 'ℹ️',
  trophy: '🏆',
  medal: '🎖️',
  star: '⭐',
  fire: '🔥',
  target: '🎯',
  apple: '🍎',
  water: '💧',
  workout: '💪',
  sleep: '😴',
  meditation: '🧘',
  joined: '🎉',
  milestone: '🎯',
  completed: '🏆',
  deleted: '🗑️',
  reset: '🔄'
} as const;